package com.example.shopcart.repository;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.example.shopcart.model.Cart;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class CartRepositoryTest {
	
	@Autowired
	private CartRepository cartRepository;
	
	@Autowired
	private TestEntityManager entity;

	@BeforeEach
	void setup() {
	    Cart cart2 = new Cart(30, "jayasai", 20, 3000.22, "Nikeshoes", "www.abc.png");
	    System.out.println(cart2);
	    entity.persist(cart2);
	}
	
	@Test
	public void testFindById() {
		String name = cartRepository.findById(30).getProductname();
		System.out.println(name);
		assertEquals("Nikeshoes", name);
	}
	

}
