package com.example.shopcart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopcartApplicationTests {

	@Test
	void contextLoads() {
	}

}
