package com.example.shopcart.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.shopcart.model.Products;
import com.example.shopcart.repository.ProductsRepository;

@Service
public class ProductsService {
    
    @Autowired
    private ProductsRepository repo;
    
    public Products postUser(Map<String,String> values) {
        
        Products temp = new Products();
        temp.setProductname(values.getOrDefault("productname", null));
        temp.setProductprice(Double.parseDouble(values.getOrDefault("productprice", "0.0")));
        temp.setProductdesc(values.getOrDefault("productdesc", null));
        temp.setProductimgurl(values.getOrDefault("productimgurl", null));
        temp.setStockavailable(Integer.parseInt(values.getOrDefault("stockavailable", "0")));
        temp.setRating(Double.parseDouble(values.getOrDefault("rating", "1.0")));
        temp.setVendorsno(Integer.parseInt(values.getOrDefault("vendorsno", "0")));
        temp.setCategory(values.getOrDefault("category", null));


        return this.repo.save(temp);
    }
    
    public String updatePrice(Map<String,String> product) {
        
        Products temp = this.repo.findByProductsid(Integer.parseInt(product.get("id")));
        if(temp != null) {
            temp.setProductprice(Double.parseDouble(product.getOrDefault("price", "0.0")));
            this.repo.save(temp);
            return "Updated Successfully";
        } else {
            return "Product not found";
        }
    }
    
	public String updateRating(Map<String,String> product) {
	        
        Products temp = this.repo.findByProductsid(Integer.parseInt(product.get("id")));
        if(temp != null) {
            temp.setRating(Double.parseDouble(product.getOrDefault("rating", "0.0")));
            this.repo.save(temp);
            return "Updated Successfully";
        } else {
            return "Product not found";
        }
    }
    
}