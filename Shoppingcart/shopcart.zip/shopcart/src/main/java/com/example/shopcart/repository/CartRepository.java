package com.example.shopcart.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.shopcart.model.Cart;

@Repository
public interface CartRepository extends JpaRepository<Cart, Integer> {
	
	Cart findById(int id);
	
	Cart findByProductid(int productid);
	
	@Transactional
    void deleteByProductid(int productid);
}
