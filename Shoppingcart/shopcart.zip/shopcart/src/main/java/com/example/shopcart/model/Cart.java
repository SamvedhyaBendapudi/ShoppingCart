package com.example.shopcart.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="cart")
public class Cart {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="username")
	private String username;
	
	@Column(name="productid")
	private int productid;
	
	@Column(name="productprice")
	private double productprice;
	
	@Column(name="productname")
	private String productname;
	
	@Column(name="productimgurl")
	private String productimgurl;

	public Cart() {
		super();
	}


	public Cart(int id, String username, int productid, double productprice, String productname, String productimgurl) {
	super();
	this.id = id;
	this.username = username;
	this.productid = productid;
	this.productprice = productprice;
	this.productname = productname;
	this.productimgurl = productimgurl;
}




	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public double getProductprice() {
		return productprice;
	}


	public void setProductprice(double productprice) {
		this.productprice = productprice;
	}


	public String getProductname() {
		return productname;
	}


	public void setProductname(String productname) {
		this.productname = productname;
	}


	public int getProductid() {
		return productid;
	}


	public void setProductid(int productid) {
		this.productid = productid;
	}


	public String getProductimgurl() {
		return productimgurl;
	}


	public void setProductimgurl(String productimgurl) {
		this.productimgurl = productimgurl;
	}
	
	
	
	
}