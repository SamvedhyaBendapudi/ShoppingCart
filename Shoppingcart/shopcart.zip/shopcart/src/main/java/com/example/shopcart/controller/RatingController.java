package com.example.shopcart.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.shopcart.model.Products;
import com.example.shopcart.model.Signup;
import com.example.shopcart.model.Rating;
import com.example.shopcart.repository.ProductsRepository;
import com.example.shopcart.repository.SignupRepository;
import com.example.shopcart.repository.RatingRepository;
import com.example.shopcart.service.ProductsService;
import com.example.shopcart.service.SignupService;
import com.example.shopcart.service.RatingService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/rating/")
public class RatingController {

	@Autowired
	private RatingRepository RatingsRepo;
	
	@Autowired
	private RatingService RatingServices;
	
	@GetMapping("all")
	public ResponseEntity<List<Rating>> getAllRatings(){
	    List<Rating> ratings = this.RatingsRepo.findAll();
	    if (!ratings.isEmpty()) {
	        return ResponseEntity.ok(ratings); // 200 OK
	    } else {
	        return ResponseEntity.status(HttpStatus.NO_CONTENT).build(); // 204 No Content
	    }
	}

	
	@PostMapping("save")
	public ResponseEntity<Rating> postRatings(@RequestBody Map<String,String> values) {
	    Rating rating = RatingServices.postRating(values);
	    if (rating != null) {
	        return ResponseEntity.status(HttpStatus.CREATED).body(rating); // 201 Created
	    } else {
	        return ResponseEntity.status(HttpStatus.BAD_REQUEST).build(); // 400 Bad Request
	    }
	}
	
	
	
}