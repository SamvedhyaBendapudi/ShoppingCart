package com.example.shopcart.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.shopcart.model.Signup;
import com.example.shopcart.repository.SignupRepository;

@Service
public class SignupService {
	
	@Autowired
	private SignupRepository repo;
	
	@Autowired
	private OtpGeneratorService otpService;

	@Autowired
	private EmailService emailService;
	
	public Signup postUser(Map<String,String> credentials) {
		
		Signup temp = new Signup();
		temp.setUsername(credentials.getOrDefault("username", null));
		temp.setPassword(credentials.getOrDefault("password", null));
		temp.setEmail(credentials.getOrDefault("email", null));
		temp.setOtp(credentials.getOrDefault("otp", null));
		temp.setNumber(credentials.getOrDefault("number", null));
		temp.setVendor(Boolean.parseBoolean(credentials.getOrDefault("vendor", "false")));
		temp.setStatus(credentials.getOrDefault("status", "Pending"));
		temp.setOtpstatus(credentials.getOrDefault("otpstatus", "Rejected"));
		return this.repo.save(temp);
		
	}
	
	public String updateOtp(Map<String,String> onlyEmail) {
		
		Signup temp = this.repo.findByEmail(onlyEmail.get("email"));
		String otp = otpService.generateOtp();
		emailService.sentOtpMail(onlyEmail.get("email"), otp);
		temp.setOtp(otp);
		this.repo.save(temp);
		return "Updated Successfully";
		
	}
	
	public String updateStatus(Map<String,String> acceptReject) {
		
		Signup temp = this.repo.findByUsername(acceptReject.get("username"));		
		temp.setStatus("Accepted");
		this.repo.save(temp);
		return "Updated Successfully";
		
	}
	
	public String updateStatus2(Map<String,String> acceptReject) {
		
		Signup temp = this.repo.findByUsername(acceptReject.get("username"));
		temp.setStatus("Rejected");
		this.repo.save(temp);
		return "Updated Successfully";
		
	}

	public String verifyOtp(Map<String, String> emailRequest) {
		System.out.println("in verifyotp func");
		Signup temp = this.repo.findByEmail(emailRequest.get("email"));
		System.out.println(temp);
		if (emailRequest.get("otp").equalsIgnoreCase(temp.getOtp())) {
			System.out.println("Success");
			temp.setOtpstatus("Accepted");
			this.repo.save(temp);
			return "Successfully verified";
		}
		else {
			System.out.println("fail");
			temp.setOtpstatus("Rejected");
			this.repo.save(temp);
			return "You have entered the wrong OTP";
		}
		
	}
	
	public boolean loginValidation(Map<String,String> loginCredentials) {
		
		Signup temp = this.repo.findByUsername(loginCredentials.get("username"));
		if (temp != null) {
	        String storedPassword = temp.getPassword(); // backend
	        String loginPassword = loginCredentials.get("password"); //frontend
	        if (storedPassword.equals(loginPassword)) {
	        	return true;
	        }
	        else {
	        	return false;
	        }
	    }
	return false;
	}

}
