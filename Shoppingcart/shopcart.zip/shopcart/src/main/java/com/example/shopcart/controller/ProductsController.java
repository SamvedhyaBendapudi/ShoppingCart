package com.example.shopcart.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.shopcart.model.Products;
import com.example.shopcart.model.Signup;
import com.example.shopcart.repository.ProductsRepository;
import com.example.shopcart.repository.SignupRepository;
import com.example.shopcart.service.ProductsService;
import com.example.shopcart.service.SignupService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/products/")
public class ProductsController {

	@Autowired
	private ProductsRepository ProductsRepo;
	
	@Autowired
	private ProductsService ProductsServices;
	
	@GetMapping("all")
	public ResponseEntity<List<Products>> getAllUsers(){
	    List<Products> products = this.ProductsRepo.findAll();
	    if (!products.isEmpty()) {
	        return ResponseEntity.ok(products); // 200 OK
	    } else {
	        return ResponseEntity.status(HttpStatus.NO_CONTENT).build(); // 204 No Content
	    }
	}

	
	@GetMapping("prods/{productsid}")
	public ResponseEntity<List<Products>> getAll(@PathVariable("productsid") String productsid) {
	    List<Products> products = this.ProductsRepo.getProdDetails(productsid);
	    if (!products.isEmpty()) {
	        return ResponseEntity.ok(products); // 200 OK
	    } else {
	        return ResponseEntity.notFound().build(); // 404 Not Found
	    }
	}

	
	@PostMapping("save")
	public ResponseEntity<Products> postUser(@RequestBody Map<String,String> values) {
	    Products product = ProductsServices.postUser(values);
	    if (product != null) {
	        return ResponseEntity.status(HttpStatus.CREATED).body(product); // 201 Created
	    } else {
	        return ResponseEntity.status(HttpStatus.BAD_REQUEST).build(); // 400 Bad Request
	    }
	}

	
	@PutMapping("pricechange")
	public ResponseEntity<String> priceingUpdate(@RequestBody Map<String,String> product) {
	    String result = ProductsServices.updatePrice(product);
	    if (result != null) {
	        return ResponseEntity.ok(result); // 200 OK
	    } else {
	        return ResponseEntity.status(HttpStatus.BAD_REQUEST).build(); // 400 Bad Request
	    }
	}
	
	@PutMapping("rate")
	public ResponseEntity<String> ratingUpdate(@RequestBody Map<String,String> value) {
	    String result = ProductsServices.updateRating(value);
	    if (result != null) {
	        return ResponseEntity.ok(result); // 200 OK
	    } else {
	        return ResponseEntity.status(HttpStatus.BAD_REQUEST).build(); // 400 Bad Request
	    }
	}
	
	
	@DeleteMapping("delete/{productsid}")
	public ResponseEntity<String> deleteUser(@PathVariable("productsid") int productsid) {
	    Products product = this.ProductsRepo.findByProductsid(productsid);
	    if (product != null) {
	        this.ProductsRepo.delete(product);
	        return ResponseEntity.ok("Deleted the Product Successfully"); // 200 OK
	    } else {
	        return ResponseEntity.notFound().build(); // 404 Not Found
	    }
	}

	
}