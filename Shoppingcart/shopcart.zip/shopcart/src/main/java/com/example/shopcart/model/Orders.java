package com.example.shopcart.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="orders")
public class Orders {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="oid")
	private int oid;
	
	@Column(name="oname")
	private String oname;
	
	@Column(name="omail")
	private String omail;
	
	@Column(name="onumber")
	private String onumber;
	
	@Column(name="ocountry")
	private String country;
	
	@Column(name="obilladdress")
	private String obilladdress;
	
	@Column(name="oshipaddress")
	private String oshipaddress;
	
	@Column(name="vsno")
	private int vsno;
	
	@Column(name="prodname")
	private String prodname;
	
	@Column(name="qty")
	private int qty;

	public Orders() {
		super();
	}
	


	public Orders(int oid, String oname, String omail, String onumber, String country, String obilladdress,
		String oshipaddress, int vsno, String prodname, int qty) {
	super();
	this.oid = oid;
	this.oname = oname;
	this.omail = omail;
	this.onumber = onumber;
	this.country = country;
	this.obilladdress = obilladdress;
	this.oshipaddress = oshipaddress;
	this.vsno = vsno;
	this.prodname = prodname;
	this.qty = qty;
}



	public int getOid() {
		return oid;
	}

	public void setOid(int oid) {
		this.oid = oid;
	}

	

	public String getOname() {
		return oname;
	}


	public void setOname(String oname) {
		this.oname = oname;
	}


	public String getOmail() {
		return omail;
	}

	public void setOmail(String omail) {
		this.omail = omail;
	}

	public String getOnumber() {
		return onumber;
	}

	public void setOnumber(String onumber) {
		this.onumber = onumber;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getObilladdress() {
		return obilladdress;
	}

	public void setObilladdress(String obilladdress) {
		this.obilladdress = obilladdress;
	}

	public String getOshipaddress() {
		return oshipaddress;
	}

	public void setOshipaddress(String oshipaddress) {
		this.oshipaddress = oshipaddress;
	}



	public int getVsno() {
		return vsno;
	}



	public void setVsno(int vsno) {
		this.vsno = vsno;
	}



	public String getProdname() {
		return prodname;
	}



	public void setProdname(String prodname) {
		this.prodname = prodname;
	}



	public int getQty() {
		return qty;
	}



	public void setQty(int qty) {
		this.qty = qty;
	}
	
	
	
	
}