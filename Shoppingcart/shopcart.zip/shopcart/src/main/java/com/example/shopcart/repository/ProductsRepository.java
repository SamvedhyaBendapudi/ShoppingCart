package com.example.shopcart.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.shopcart.model.Products;

@Repository
public interface ProductsRepository extends JpaRepository<Products, Integer> {
	
	Products findByProductsid(int productsid);
	
	@Query(value= "SELECT * FROM products where productsid=:productsid", nativeQuery = true)
	public List<Products> getProdDetails(@Param("productsid") String productsid);
	
}
