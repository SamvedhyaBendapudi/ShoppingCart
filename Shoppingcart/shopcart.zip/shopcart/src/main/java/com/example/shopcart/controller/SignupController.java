package com.example.shopcart.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.shopcart.model.Signup;
import com.example.shopcart.repository.SignupRepository;
import com.example.shopcart.service.SignupService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/signup/")
public class SignupController {

	@Autowired
	private SignupRepository SignupRepo;
	
	@Autowired
	private SignupService SignupServices;
	
	@GetMapping("all")
	public ResponseEntity<List<Signup>> getAllUsers(){
	    List<Signup> users = this.SignupRepo.findAll();
	    if (!users.isEmpty()) {
	        return ResponseEntity.ok(users); // 200 OK
	    } else {
	        return ResponseEntity.status(HttpStatus.NO_CONTENT).build(); // 204 No Content
	    }
	}

	
	@PostMapping("validation")
	public boolean validation(@RequestBody Map<String,String> loginCredentials) {
		return this.SignupServices.loginValidation(loginCredentials);
	}
	
	@PostMapping("save")
	public ResponseEntity<Signup> postUser(@RequestBody Map<String,String> credentials) {
	    Signup user = SignupServices.postUser(credentials);
	    if (user != null) {
	        return ResponseEntity.status(HttpStatus.CREATED).body(user); // 201 Created
	    } else {
	        return ResponseEntity.status(HttpStatus.BAD_REQUEST).build(); // 400 Bad Request
	    }
	}
	
	@PutMapping("otp")
	public ResponseEntity<String> putOtp(@RequestBody Map<String,String> onlyEmail) {
	    String result = SignupServices.updateOtp(onlyEmail);
	    if (result.equals("Updated Successfully")) {
	        return ResponseEntity.ok(result); // 200 OK
	    } else {
	        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(result); // 404 Not Found
	    }
	}
	
	@PutMapping("status")
	public ResponseEntity<String> statusUpdate(@RequestBody Map<String,String> acceptReject) {
	    String result = SignupServices.updateStatus(acceptReject);
	    if (result.equals("Updated Successfully")) {
	        return ResponseEntity.ok(result); // 200 OK
	    } else {
	        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(result); // 404 Not Found
	    }
	}
	
	@PutMapping("status2")
	public ResponseEntity<String> status2Update(@RequestBody Map<String,String> acceptReject) {
	    String result = SignupServices.updateStatus2(acceptReject);
	    if (result.equals("Updated Successfully")) {
	        return ResponseEntity.ok(result); // 200 OK
	    } else {
	        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(result); // 404 Not Found
	    }
	}

//	@PostMapping("verify")
//	public ResponseEntity<String> verifyOtp(@RequestBody Map<String,String> emailRequest) {
//	    String result = SignupServices.verifyOtp(emailRequest);
//	    if (result.equals("Verified Successfully")) {
//	        return ResponseEntity.ok(result); // 200 OK
//	    } else {
//	        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(result); // 401 Unauthorized
//	    }
//	}
	@PostMapping("verify")
	public String verifyOtp(@RequestBody Map<String,String> emailRequest) {
		return SignupServices.verifyOtp(emailRequest);
		
	}

	@DeleteMapping("delete/{username}")
	public ResponseEntity<String> deleteUser(@PathVariable("username") String username) {
	    Signup user = this.SignupRepo.findByUsername(username);
	    if (user != null) {
	        this.SignupRepo.delete(user);
	        return ResponseEntity.ok("Deleted the User Successfully"); // 200 OK
	    } else {
	        return ResponseEntity.notFound().build(); // 404 Not Found
	    }
	}

	
}
