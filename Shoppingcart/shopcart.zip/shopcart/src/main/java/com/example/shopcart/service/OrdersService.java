package com.example.shopcart.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.shopcart.model.Orders;
import com.example.shopcart.repository.OrdersRepository;

@Service
public class OrdersService {
    
    @Autowired
    private OrdersRepository repo;
    
    public Orders postOrder(Map<String,String> values) {
        
    	Orders temp = new Orders();
    	temp.setOname(values.getOrDefault("oname", null));
    	temp.setOmail(values.getOrDefault("omail", null));
    	temp.setOnumber(values.getOrDefault("onumber", null));
    	temp.setCountry(values.getOrDefault("country", null));
    	temp.setObilladdress(values.getOrDefault("obilladdress", null));
    	temp.setOshipaddress(values.getOrDefault("oshipaddress", null));
    	temp.setVsno(Integer.parseInt(values.getOrDefault("vsno", "0")));
    	temp.setProdname(values.getOrDefault("prodname", null));
    	temp.setOshipaddress(values.getOrDefault("oshipaddress", null));
    	temp.setQty(Integer.parseInt(values.getOrDefault("qty", "0")));
    	
        return this.repo.save(temp);
    }

}