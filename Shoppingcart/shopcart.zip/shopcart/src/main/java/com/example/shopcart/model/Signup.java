package com.example.shopcart.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="signup")
public class Signup {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="sno")
	private int sno;
	
	@Column(name="username")
	private String username;
	
	@Column(name="password")
	private String password;
	
	@Column(name="email")
	private String email;
	
	@Column(name="number")
	private String number;
	
	@Column(name="otp")
	private String otp;
	
	@Column(name="vendor")
	private boolean vendor;
	
	@Column(name="status")
	private String status;
	
	@Column(name="otpstatus")
	private String otpstatus;

	public Signup() {
		super();
	}

	public Signup(String username, String password, String email, String number, String otp, boolean vendor, String status, String otpstatus) {
		super();
		this.username = username;
		this.password = password;
		this.email = email;
		this.number = number;
		this.otp = otp;
		this.vendor = vendor;
		this.status = status;
		this.otpstatus = otpstatus;
	}

	public int getSno() {
		return sno;
	}

	public void setSno(int sno) {
		this.sno = sno;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public boolean isVendor() {
		return vendor;
	}

	public void setVendor(boolean vendor) {
		this.vendor = vendor;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getOtpstatus() {
		return otpstatus;
	}

	public void setOtpstatus(String otpstatus) {
		this.otpstatus = otpstatus;
	}

	
	
	
}