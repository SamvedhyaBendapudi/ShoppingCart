package com.example.shopcart.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="rating")
public class Rating {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ratingid")
	private int ratingid;
	
	@Column(name="username")
	private String username;
	
	@Column(name="productsid")
	private int productsid;
	
	@Column(name="userrating")
	private double userrating;
	
	@Column(name="userreview")
	private String userreview;


	public Rating() {
		super();
	}



	public Rating(int ratingid, String username, int productsid, double userrating, String userreview) {
		super();
		this.ratingid = ratingid;
		this.username = username;
		this.productsid = productsid;
		this.userrating = userrating;
		this.userreview = userreview;
	}


	public int getRatingid() {
		return ratingid;
	}



	public void setRatingid(int ratingid) {
		this.ratingid = ratingid;
	}



	public String getUsername() {
		return username;
	}



	public void setUsername(String username) {
		this.username = username;
	}



	public int getProductsid() {
		return productsid;
	}



	public void setProductsid(int productsid) {
		this.productsid = productsid;
	}



	public double getUserrating() {
		return userrating;
	}



	public void setUserrating(double userrating) {
		this.userrating = userrating;
	}



	public String getUserreview() {
		return userreview;
	}



	public void setUserreview(String userreview) {
		this.userreview = userreview;
	}
	
	
}