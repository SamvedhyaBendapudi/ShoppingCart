package com.example.shopcart.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.shopcart.model.Cart;
import com.example.shopcart.repository.CartRepository;

@Service
public class CartService {
    
    @Autowired
    private CartRepository repo;
    
    public Cart postUser(Map<String,String> values) {
        try {
            Cart temp = new Cart();
            temp.setUsername(values.getOrDefault("username", null));
            temp.setProductname(values.getOrDefault("productname", null));
            temp.setProductid(Integer.parseInt(values.getOrDefault("productsid", "0")));
            temp.setProductprice(Double.parseDouble(values.getOrDefault("productprice", "0.0")));
            temp.setProductimgurl(values.getOrDefault("productimgurl", null));
            
            return this.repo.save(temp);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid product ID or price format");
        } catch (Exception e) {
            throw new RuntimeException("Error occurred while saving the cart", e);
        }
    }
    
    public void deleteProdFromCart(int productid) {
        repo.deleteByProductid(productid);
    }

}