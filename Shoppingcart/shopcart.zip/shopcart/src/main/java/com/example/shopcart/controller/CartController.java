package com.example.shopcart.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.shopcart.model.Products;
import com.example.shopcart.model.Signup;
import com.example.shopcart.model.Cart;
import com.example.shopcart.repository.ProductsRepository;
import com.example.shopcart.repository.SignupRepository;
import com.example.shopcart.repository.CartRepository;
import com.example.shopcart.service.ProductsService;
import com.example.shopcart.service.SignupService;
import com.example.shopcart.service.CartService;


@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/cart/")
public class CartController {

	@Autowired
	private CartRepository CartRepo;
	
	@Autowired
	private CartService CartServices;
	
	@GetMapping("all")
	public ResponseEntity<List<Cart>> getAllUsers(){
	    try {
	        List<Cart> users = this.CartRepo.findAll();
	        return ResponseEntity.ok(users);
	    } catch (Exception e) {
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
	    }
	}

	
	@PostMapping("save")
	public ResponseEntity<Cart> postUser(@RequestBody Map<String,String> values) {
	    try {
	        Cart cart = CartServices.postUser(values);
	        return ResponseEntity.ok(cart);
	    } catch (Exception e) {
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
	    }
	}

	
	@DeleteMapping("delete/{id}")
	public ResponseEntity<String> deleteSingleFromCart(@PathVariable("id") int id) {
	    Cart temp = this.CartRepo.findById(id);
	    if (temp != null) {
	        this.CartRepo.delete(temp);
	        return ResponseEntity.noContent().build();
	    } else {
	        return ResponseEntity.notFound().build();
	    }
	}

	
	@DeleteMapping("deleteproduct/{productid}")
	public ResponseEntity<String> deleteProdFromCart(@PathVariable("productid") int productid) {
	    CartServices.deleteProdFromCart(productid);
	    return ResponseEntity.status(HttpStatus.OK).body("Deleted all products with Product ID: " + productid + " from the cart successfully");
	}
	
}