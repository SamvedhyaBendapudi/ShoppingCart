package com.example.shopcart.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.shopcart.model.Rating;
import com.example.shopcart.repository.RatingRepository;

@Service
public class RatingService {
    
    @Autowired
    private RatingRepository repo;
    
    public Rating postRating(Map<String,String> values) {
        
        Rating temp = new Rating();
        temp.setUsername(values.getOrDefault("username", null));
        temp.setProductsid(Integer.parseInt(values.getOrDefault("productsid", "0")));
        temp.setUserrating(Double.parseDouble(values.getOrDefault("userrating", "0.0")));
        temp.setUserreview(values.getOrDefault("userreview", null));
        
        return this.repo.save(temp);
    }
    
    
	public String updateRating(Map<String,String> values) {
	        
        Rating temp = this.repo.findByProductsid(Integer.parseInt(values.get("id")));
        if(temp != null) {
            temp.setUserrating(Double.parseDouble(values.getOrDefault("userrating", "0.0")));
            this.repo.save(temp);
            return "Updated Successfully";
        } else {
            return "Product not found";
        }
    }
    
}