package com.example.shopcart.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.shopcart.model.Signup;

@Repository
public interface SignupRepository extends JpaRepository<Signup, Integer> {
	
	Signup findByUsername(String Username);

	Signup findByEmail(String Email);
	
	Signup findByNumber(String Number);
	
	Signup findByStatus (String Status);
	
	Signup findByVendor(boolean Vendor);
	
	Signup findBySno(int Sno);
}
