package com.example.shopcart.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="products")
public class Products {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="productsid")
	private int productsid;
	
	@Column(name="productname")
	private String productname;
	
	@Column(name="productprice")
	private double productprice;
	
	@Column(name="productdesc")
	private String productdesc;
	
	@Column(name="productimgurl")
	private String productimgurl;
	
	@Column(name="stockavailable")
	private int stockavailable;
	
	@Column(name="vendorsno")
	private int vendorsno;
	
	@Column(name="rating")
	private double rating;
	
	@Column(name="category")
	private String category;


	public Products() {
		super();
	}
	



	public Products(int productsid, String productname, double productprice, String productdesc, String productimgurl,
			int stockavailable, int vendorsno, double rating, String category) {
		super();
		this.productsid = productsid;
		this.productname = productname;
		this.productprice = productprice;
		this.productdesc = productdesc;
		this.productimgurl = productimgurl;
		this.stockavailable = stockavailable;
		this.vendorsno = vendorsno;
		this.rating = rating;
		this.category = category;
	}




	public int getProductsid() {
		return productsid;
	}


	public void setProductsid(int productsid) {
		this.productsid = productsid;
	}


	public String getProductname() {
		return productname;
	}



	public void setProductname(String productname) {
		this.productname = productname;
	}



	public double getProductprice() {
		return productprice;
	}



	public void setProductprice(double productprice) {
		this.productprice = productprice;
	}



	public String getProductdesc() {
		return productdesc;
	}



	public void setProductdesc(String productdesc) {
		this.productdesc = productdesc;
	}



	public String getProductimgurl() {
		return productimgurl;
	}



	public void setProductimgurl(String productimgurl) {
		this.productimgurl = productimgurl;
	}



	public int getStockavailable() {
		return stockavailable;
	}



	public void setStockavailable(int stockavailable) {
		this.stockavailable = stockavailable;
	}


	public double getRating() {
		return rating;
	}


	public void setRating(double rating) {
		this.rating = rating;
	}


	public int getVendorsno() {
		return vendorsno;
	}

	public void setVendorsno(int vendorsno) {
		this.vendorsno = vendorsno;
	}


	public String getCategory() {
		return category;
	}


	public void setCategory(String category) {
		this.category = category;
	}
	
	
	
	
}