module.exports = {
    //...
   resolve: {
     alias: {
       '@mui/material': '@mui/joy',
     },
   },
  };
 